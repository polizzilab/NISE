from pathlib import Path
from carp_dock import main as run_carp_dock

ligand_path = Path('./apixaban_ntf2_screen2/apix_conf2.pdb')
output_path = Path('./apixaban_ntf2_screen2/carpdock_out/')
output_path.mkdir(exist_ok=True)

constraints = {
    'inside_hull': ['O4', 'O2', 'O3', 'C25'], 
    'outside_hull': []
}

for backbone in sorted(list(Path('./example_backbones_ntf2/').glob('*.pdb'))):
    subdir = output_path / backbone.stem
    if subdir.exists():
        continue
    subdir.mkdir()

    run_carp_dock(backbone, ligand_path, subdir.absolute(), constraints, device='cuda:0', clustering_algorithm='kmeans', kmeans_nclusters=100, test_point_grid_width=0.5, alpha=9.0)

all_laser_inputs_paths = sorted(list(output_path.glob('*/*.pdb')))
laser_input_path_txt_file = Path("laser_input_paths.txt")
with laser_input_path_txt_file.open("w") as f:
    for path in all_laser_inputs_paths:
        f.write(f"{path.absolute()}\n")

import shutil
with open('laser_input_paths.txt', 'r') as f:
    for line in f.readlines():
        line = Path(line.strip())
        if line.stem.startswith('cluster'):
            shutil.move(line, line.parent / f'{line.parent.stem}-{line.stem}.pdb')

all_laser_inputs_paths = sorted(list(output_path.glob('*/*.pdb')))
laser_input_path_txt_file = Path("laser_input_paths.txt")
with laser_input_path_txt_file.open("w") as f:
    for path in all_laser_inputs_paths:
        f.write(f"{path.absolute()}\n")

import subprocess
path_to_lasermpnn = Path("/nfs/polizzi/bfry/programs/LASErMPNN")
lasermpnn_output_path = output_path.parent / 'laser_outputs'
subprocess.run(f"cd {path_to_lasermpnn.parent}; python -m LASErMPNN.run_batch_inference {laser_input_path_txt_file.absolute()} {lasermpnn_output_path.absolute()} 3 -d cuda:0 --silent -n 35", shell=True)
