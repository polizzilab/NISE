#!/usr/bin/env python3

import sys
import subprocess
from pathlib import Path

def main(input_, output_, device):
    input_ = Path(input_)
    output_ = Path(output_)

    if not output_.exists():
        output_.mkdir(exist_ok=True)

    subprocess.run(f'pushd /home/nickhedu/programs/modelforge; CUDA_VISIBLE_DEVICES={device} ~/miniforge3/envs/rf3/bin/rf3 fold inputs={input_.absolute()} out_dir={output_.absolute()} num_steps=200 early_stopping_plddt_threshold=null diffusion_batch_size=1; popd', shell=True)

if __name__ == '__main__':
    device = '0'
    try:
        device = sys.argv[3]
    except:
        pass
    main(sys.argv[1], sys.argv[2], device)