# Full APEX (Apixaban Binder) Protein Design Workflow


## Prerequisites:
- [CARPdock](https://github.com/benf549/CARPdock)
- [LASErMPNN](https://github.com/polizzilab/LASErMPNN)
- [Boltz-2x](https://github.com/jwohlwend/boltz)
- [RoseTTAFold3](https://github.com/RosettaCommons/foundry/tree/production/models/rf3)
- [AlphaFold2](https://github.com/YoshitakaMo/localcolabfold) (using LocalColabFold Interface)
- [Rosetta](https://github.com/RosettaCommons/rosetta) (using RosettaScripts Interface)


## Note:
These scripts were created using the software available on the Polizzi Lab's specific HPC infrastructure, 
they will not work on your machine without tweaking file paths and installation locations. 
However, they contain the exact protocol used to identify APEX a $K_d = 80 \pm 40$ pM NTF2 protein fold binder to the drug apixaban


# Stage 1: Rigid Protein-Ligand Docking with CARPdock

For each apixaban conformer from 6w70 extracted as a PDB file run the following:

### 1.1 Generate CARPdock poses

```
00_carpdock_screen_apx_ntf2.py 
```
(`00_carpdock_screen_apx_ntf2_2.py` handles this process for the second apx conformer)

### 1.2 Gather all input paths for LASErMPNN and run it.

```
01_get_paths_txt.ipynb
```


```bash
conda activate lasermpnn
python LASErMPNN.run_batch_inference ./laser_inputs_paths.txt ./laser_outputs/ 3 -d cuda:0
```


### 1.3 Run Boltz-2x on LASErMPNN outputs

```
02_get_boltz_inputs.ipynb
```

```bash
conda activate boltz2
boltz predict --use_potentials --output_format pdb --devices 8 ./boltz_inputs/
```

### 1.4 Second round of sequence design and structure prediction to nominate final top backbones

```
04_run_1round_nise.ipynb
```
This writes top backbones to `./nise_round1_apixaban_ntf2_top20/`.

Select top-3 unique poses for each apixaban conformer.

# Stage 2: Run NISE

For each unique pose from CARPdock, create an input directory like `pose_00/input_backbones/pose.pdb`.

### 2.1 Run NISE optimization protocol:

```
00_run_nise_boltz_2x_pose00.py
```

Once this completes, move into run outputs directory `./pose_00/` 

### 2.2 Run filtering and ranking to get top poses NISE trajectory

```
./pose_00/01_rank_top_by_bun_pose_newrank.ipynb
```

This will dump the top 250 poses for the nise trajectory to `./top_designs_by_bbuns`


# Stage 3: Re-screen with AlphaFold2 and RoseTTAFold3

### 3.1 Re-predict first with AlphaFold2 using localcolabfold interface.

```
00_submit_alphafold2.ipynb
```

### 3.2 Filter and screen the remaining poses with RoseTTAFold3 

Run the notebook partially to generate `./rf3_inputs_?_.json` files and run `./run_rf3.py ./rf3_inputs_?_.json ./rf3_outputs/ ?` where `?` is the GPU device ordinal for each chunk).
Then inspect the outputs of RF3 by continuing the execution of the notebook.

```
01_check_rf3.ipynb
```

### 3.3 Filter and rank top poses by BUNs Score tie-breaking by RF3 Ligand pLDDT

```
02_bunsalyze.ipynb
```


