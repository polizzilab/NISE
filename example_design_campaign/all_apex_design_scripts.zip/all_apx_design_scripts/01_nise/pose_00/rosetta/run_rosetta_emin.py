import argparse
import asyncio
import subprocess
from pathlib import Path

default_rosetta_script_path = '/nfs/sbgrid/programs/x86_64-linux/rosetta/3.13/main/source/bin/rosetta_scripts.default.linuxgccrelease'
default_rosetta_database_path = '/nfs/sbgrid/programs/x86_64-linux/rosetta/3.13/main/database'

curr_file_parent_path = Path(__file__).parent.resolve()
emin_and_score_interactions_xml_path = curr_file_parent_path / 'rosetta_script_fixbb_relax_sidechains.xml'
repack_and_emin_xml_path = curr_file_parent_path / 'rosetta_script_fixbb_relax_apo.xml'

def parse_args() -> dict:
    parser = argparse.ArgumentParser(description='Run rosetta relax')
    parser.add_argument('pdb_path', type=str, help='Path to pdb file.')
    parser.add_argument('ligand_params_path', type=str, help='Path to ligand params file.')
    parser.add_argument('--output_dir', '-o', type=str, default='./', help='Path to output file.')
    parser.add_argument('--optH', action='store_true', default=False, help='Optimize hydrogen bonds with Rosetta.')
    parsed_args = vars(parser.parse_args())
    return parsed_args


async def run_subprocess(command_string: str) -> None:
    loop = asyncio.get_event_loop()
    await loop.run_in_executor(None, lambda x: subprocess.run(x, shell=True), command_string)


async def main(pdb_path: str, ligand_params_path: str, output_dir: str, optH: bool) -> None:
    command_1 = f'{default_rosetta_script_path} -database {default_rosetta_database_path} -s {pdb_path} -extra_res_fa {ligand_params_path} -out:path:all {output_dir} -out:suffix _rosetta_emin -out:file:fullatom -parser:protocol {emin_and_score_interactions_xml_path} -overwrite -no_optH {not optH} -inout:skip_connect_info -out:path:score /dev/null -out:level 100 -out:no_nstruct_label'
    command_2 = f'{default_rosetta_script_path} -database {default_rosetta_database_path} -s {pdb_path} -ignore_unrecognized_res -in:file:load_PDB_components false -out:path:all {output_dir} -out:suffix _rosetta_apo_repack_emin -out:file:fullatom -parser:protocol {repack_and_emin_xml_path} -overwrite -no_optH {not optH} -inout:skip_connect_info -out:path:score /dev/null -out:level 100 -out:no_nstruct_label'
    await asyncio.gather(run_subprocess(command_1), run_subprocess(command_2))


if __name__ == "__main__":
    parsed_args = parse_args()
    asyncio.run(main(**parsed_args))




